import React from 'react';
import { connect } from 'react-redux';
import {withStyles} from '@material-ui/core';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';

const style = theme => ({
    table: {
        minWidth: 650,
      },
      tableContainer:{
        alignContent: 'center',
        justifyContent: 'center',
        display: 'flex',
        // height:'550px'
    },
    gridContainer:{
      marginTop:'100px'
    }
})

function CarsListTable(props) {
    const {classes} = props;
    var uniq = 'id_' + (new Date()).getTime();
  return (
<Grid container className={classes.tableContainer}>
        <Grid className={classes.gridContainer} item xs={8}>
        <TableContainer component={Paper}>
          <Table className={classes.table} size="medium" aria-label="a dense table">
            <TableHead>
              <TableRow>
                <TableCell>Id (Num)</TableCell>
                <TableCell align="right">Name</TableCell>
                <TableCell align="right">Card Number</TableCell>
                <TableCell align="right">Card Expiry Date</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {Array.isArray(props.addCardData) && props.addCardData.map((item,index) => (
                <TableRow key={index}>
                  <TableCell component="th" scope="row">{uniq}</TableCell>
                  <TableCell align="right">{item.name}</TableCell>
                  <TableCell align="right">{item.cardNumber}</TableCell>
                  <TableCell align="right">{item.expiryDate}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
      </TableContainer>
      </Grid>
      </Grid>
  );
}


function mapStateToProps(state){
    return {
        addCardData : state.addCardList.addCardList,
    }
  }

export default connect(mapStateToProps)(withStyles(style)(CarsListTable))
