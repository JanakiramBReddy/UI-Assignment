import React from 'react';
import {withStyles} from '@material-ui/core';
import { connect } from 'react-redux';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Typography from '@material-ui/core/Typography';
import {AddcardList} from '../actions/addCardListAction';
import CarsListTable from './cardListTable';
import Cleave from 'cleave.js/react';

const style = theme => ({
    root:{
        position: 'relative',
        margin: '20px auto',
        background: '#fff',
        overflow: 'hidden',
        borderRadius: '5px',
        boxShadow: '0 1px 5px 0 rgba(0,0,0,.15)',
        width: '100%',
        minHeight: '400px',
        maxWidth: '325px',
        padding: '20px 4vw 60px'
    },title:{
        textAlign:'center',
        color: 'rgb(0, 0, 0)',
        fontWeight:'500'
    },subtitle:{
        textAlign:'center',
        color: 'rgb(0, 0, 0)',
        fontSize: '14px',
        fontWeight: '400',
        letterSpacing: '0',
        margin:'8px 8px'
    },fieldContainer: {
        position: 'relative',
        marginBottom:'15px'
    },formContainer : {
        display: 'grid',
        maxWidth: '400px',
        color: '#707070',
        marginTop:'30px'
    },label: {
        paddingBottom: '5px',
        fontSize: '13px'
    },
    inputbox:{
        width:'100%',
        marginTop: '3px',
        padding: '10px',
        fontSize: '16px',
        width: '100%',
        borderRadius: '3px',
        border: '1px solid #dcdcdc'
    },
    labelStyle:{
        color: 'rgb(0, 0, 0)',
    },
    button:{
        backgroundColor: '#008CBA',
        border: 'none',
        color: 'white',
        padding: '15px 32px',
        textAlign: 'center',
        textDecoration: 'none',
        display: 'inline-block',
        fontSize: '16px',
        margin: '4px 2px',
        cursor: 'pointer',
        borderRadius:'4px'
    }

})

class CreditCardAdd extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            name: '',
            cardNumber:'',
            expiryDate:'',
            cvvCode:'',
        };
    
        this.cardholderName = this.cardholderName.bind(this);
        this.cardNumber = this.cardNumber.bind(this);
        this.expiryNumber = this.expiryNumber.bind(this);
        this.securityNumber = this.securityNumber.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
      }


      cardholderName(event) {
        this.setState({name: event.target.value});
      }
    cardNumber(event) {
        this.setState({cardNumber: event.target.value});
    }
      expiryNumber(event) {
        this.setState({expiryDate: event.target.value});
      }
      securityNumber(event) {
        this.setState({cvvCode: event.target.value});
      }

      handleSubmit(event) {
        event.preventDefault();
        var dataList = [];
        const cardDetils = {
            name : this.state.name,
            cardNumber: this.state.cardNumber,
            expiryDate : this.state.expiryDate,
            cvvCode : this.state.cvvCode
        }
        
        this.setState({
            name: '',
            cardNumber:'',
            expiryDate:'',
            cvvCode:''
          });
        this.props.AddcardList(cardDetils)
        
      }

    render(){
        const { addCardData,classes } = this.props;
        return(
            <div>
            <Card className={classes.root} variant="outlined">
                <CardContent style={{padding: '16px 8px'}}>
                    <Typography variant="h5" className={classes.title} component="h2">
                       Add Credit Card
                    </Typography>
                    <Typography className={classes.subtitle}>
                        Add your credit card with secured way
                    </Typography>
                    <form onSubmit={this.handleSubmit}>
                        <div className={classes.formContainer}>
                            <div className={classes.fieldContainer}>
                                    <label className={classes.labelStyle} htmlFor="card holder name">Name</label>
                                    <input type="text" value={this.state.name} placeholder="Enter cardholder name" className={classes.inputbox} onChange={this.cardholderName}/>
                                </div>
                                
                                <div className={classes.fieldContainer}>
                                    <label className={classes.labelStyle} htmlFor="cardnumber">Card Number</label>
                                    <Cleave className={classes.inputbox} placeholder="Enter credit card number"
                                    options={{creditCard: true}} value={this.state.cardNumber}
                                    onChange={this.cardNumber} />
                                </div>
                                <div style={{display:'inline-flex'}}>
                                    <div className={classes.fieldContainer}>
                                        <label className={classes.labelStyle} htmlFor="expirationdate">Expiration (mm/yy)</label>
                                        <Cleave
                                            placeholder="MM/YY"
                                            options={{ date: true, datePattern: ["m", "d"] }}
                                            value={this.state.expiryDate} style={{width:'65%'}}
                                             className={classes.inputbox} onChange={this.expiryNumber}
                                            />
                                    </div>
                                    <div className={classes.fieldContainer}>
                                        <label className={classes.labelStyle} htmlFor="securitycode">Security Code</label>
                                        <Cleave
                                        placeholder="CVV" value={this.state.cvvCode}
                                        options={{
                                            blocks: [3],
                                            numericOnly: true
                                        }} style={{width:'75%'}}
                                        onChange={this.securityNumber}
                                        className={classes.inputbox}
                                        />
                                    </div>
                                </div>
                            </div>
                            <input className={classes.button} type="submit" style={{flex:'1'}} value="Add Card" />
                         </form>
                </CardContent>
            </Card>
            <CarsListTable />
            </div>
        )
    }
}




const mapDispatchToProps = dispatch => ({
    AddcardList : x => dispatch(AddcardList(x))
  })
  
  
  function mapStateToProps(state){
    return {
        addCardData : state.addCardList.addCardList
    }
  }
  
  export default connect(mapStateToProps,mapDispatchToProps)(withStyles(style)(CreditCardAdd))




