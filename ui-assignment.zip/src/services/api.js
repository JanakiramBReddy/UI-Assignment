import axios from "axios";

export function getModuleListResponse(){
    return axios.get('https://stgapi.omnicuris.com/api/v3/courses?courseSlug=thyroid-in-pregnancy',
        {
            headers: { 'hk-access-token': '89e684ac-7ade-4cd8-bbdf-419a92f4cc5f8'}
        });
}