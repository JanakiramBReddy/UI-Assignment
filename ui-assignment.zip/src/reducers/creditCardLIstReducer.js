
const initialState = {
    addCardList : [],
}

export default function(state = initialState,action){

    switch(action.type){
        case "CARDADD_LIST_SUCCESS":
            state.addCardList.push(action.cardDetails)
            return {
                ...state,
                addCardList:state.addCardList
            }
        case "CARDADD_LIST_FAILURE":
            state.addCardList.push(action.cardDetails)
            return {
                ...state,
                addCardList:state.addCardList
            }
        default:
    }
    return state;
}