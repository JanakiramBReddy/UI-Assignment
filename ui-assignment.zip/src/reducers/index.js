import {combineReducers} from 'redux';
import CreditCardListReducer from './creditCardLIstReducer';

export default combineReducers({
    addCardList:CreditCardListReducer
});


