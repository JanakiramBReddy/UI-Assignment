import keyMirror from 'fbjs/lib/keyMirror';

export const AddCardActions = keyMirror({
    CARDADD_LIST : undefined,
    CARDADD_LIST_SUCCESS: undefined,
    CARDADD_LIST_FAILURE : undefined
})