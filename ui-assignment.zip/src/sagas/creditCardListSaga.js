import {call,all,put,takeLatest} from 'redux-saga/effects';
import  {AddCardActions}  from '../constants/actionTypes';

export function* AddCreditcardList(args){
    try{
        localStorage.setItem('mycardDetails', args.payload);
        yield put({
            type:AddCardActions.CARDADD_LIST_SUCCESS,
            cardDetails:args.payload,
        })
    }
    catch(err){
        yield put({
            type:AddCardActions.CARDADD_LIST_FAILURE,
        })
    }
}

export default function* root(){
    yield all([
        takeLatest(AddCardActions.CARDADD_LIST,AddCreditcardList)
    ])
}