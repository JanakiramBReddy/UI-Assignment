import {all,fork} from 'redux-saga/effects';
import AddCreditcardList from './creditCardListSaga';

export default function* root(){
    yield all([
        fork(AddCreditcardList)
    ])
}