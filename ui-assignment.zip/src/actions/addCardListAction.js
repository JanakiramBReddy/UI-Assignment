import  { createAction } from 'redux-actions';
import { AddCardActions } from '../constants/actionTypes';

export const AddcardList = createAction(AddCardActions.CARDADD_LIST)