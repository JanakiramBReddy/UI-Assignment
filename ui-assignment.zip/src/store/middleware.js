import createSagaMiddleware from 'redux-saga';
import logger from 'redux-logger';

export const sagaMiddleware = createSagaMiddleware();

const middleware = [sagaMiddleware,logger];

export default middleware;