import React from 'react';
import Grid from '@material-ui/core/Grid';
import CreditCardAdd from '../src/components/creditCardAdd';

function App() {
  return (
    <div className="App">
      <Grid container>
          <Grid item xs={12}>
          <CreditCardAdd />
          </Grid>
      </Grid>
    </div>
  );
}

export default App;
